#include "arch_checker.h"

int main(void){
	int a = 15213;
	printf("int a=15213; \n");
	show_bytes((pointer)&a, sizeof(int));
	//Byte Ordering check -> little Endian

	long b= 15213;
	printf("long b=15213; \n");

	show_bytes((pointer)&b, sizeof(long));
	//bit check, 32bit 4bytes, 64bit 8bytes->64bit
	
	return 0;
}
