#include <stdio.h>

typedef unsigned char *pointer;

void show_bytes(pointer start, size_t len);
